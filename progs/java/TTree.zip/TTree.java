import java.util.LinkedList;
import java.util.Queue;

/* Node structure
 * TODO: Ideally, the data element should be a class that implements Comparator,
 * something like
 * class Node<T extends Comparator> {
 * ...
 *   T data;
 *   }
 */
class Node {
  Node left, right, middle;
  int data; //Can use a more complex structure that implements Comparator interface
  public Node(int i) {
    this.left = null;
    this.right = null;
    this.middle = null;
    this.data = i;
  }

  public String toString() {
    return "" + this.data;
  }
}


/* The tree that holds all nodes.
 * Based on the Node's data element, the insert/delete
 * signatures would have to be changed
 */
public class TTree {
  // Test the given sample, add the nodes
  // breadth first traverse it.
  // Delete them, and traverse after each delete to test.
  public static void main(String a[] ) {
    TTree tree = new TTree();
    tree.traverse();
    tree.insert(5);
    tree.insert(4);
    tree.insert(9);
    tree.insert(5);
    tree.insert(7);
    tree.insert(2);
    tree.insert(2);

    tree.traverse();
    System.out.println("insert complete, deleting all added nodes...");

    tree.delete(5);
    tree.traverse();
    tree.delete(4);
    tree.traverse();
    tree.delete(9);
    tree.traverse();
    tree.delete(5);
    tree.traverse();
    tree.delete(7);
    tree.traverse();
    tree.delete(2);
    tree.traverse();
    tree.delete(2);
    tree.traverse();
  }


  private Node root ;

  public TTree() {
  }

  // Public method
  public void insert(int n) {
    Node node = new Node(n);
    if( root == null )
      root = node;
    else
      insert(root, node);
  }

  /* Internally used recursively by the TTree class
   * to find the node to attach the child to
   */
  private void insert(Node parent, Node child) {
    if ( child == null ) return;

    if ( parent == null ) { // Root node, specifically hacked for delete
      parent = child;
      if( root == null )
        root = parent;
    }

    if( child.data < parent.data ) {
      if( parent.left == null )
        parent.left = child;
      else
        insert( parent.left, child);
    } else if( child.data > parent.data ) {
      if( parent.right == null )
        parent.right = child;
      else
        insert( parent.right, child);
    } else {
      if( parent.middle == null )
        parent.middle = child;
      else
        insert( parent.middle, child);
    }
  }


  // publicly accessible delete node
  public boolean delete(int n) {
    if( null == root ) return false;
    Node retNode = delete(root, n);
    return ( retNode != null )  ;
  }

  /* Find the deepest matched node to delete
   * i.e. the matched node will always have its middle null
   * Save the left and right of the "found" node and insert
   * them back to the parent node, (recursively)
   * ASSUMPTION: while deleting root, we choose the left node
   *             as the new root. It is trivial to pick one over other
   */
  private Node delete(Node node, int value) {
    Node found = null;
    Node left = null;
    Node right = null;

    if( value == node.data ) {
      if( node.middle != null ) {
        found = delete(node.middle, value);
        node.middle = null;
      } else {
        if( node != root ) {
          return node;
        } else {
          found = root;
          node = null;
          root = null;
        }
      }
    } else if ( value < node.data ) {
      found = delete(node.left, value);
      node.left = null;
    } else {
      found = delete(node.right, value);
      node.right = null;
    }
    left = found.left;
    right = found.right;
    found = null;
    if( root == null ) {
      root = left;
      node = root;
    } else {
      insert(node, left);
    }
    insert(node, right);
    return node;
  }

  public void traverse() {
    traverse(root);
  }

  /* Breadth first traversal using a simple Queue
   * Utility method to test inserts and deletes
   */
  public void traverse(Node n) {
    if( null == n ) {
      return;
    }
    queue.clear();
    queue.add(root);
    while( !queue.isEmpty() ) {
      Node node = queue.remove();
      System.out.print( " " + node.data );
      if( node.left != null ) queue.add(node.left);
      if( node.middle != null ) queue.add(node.middle);
      if( node.right != null ) queue.add(node.right);
    }
    System.out.println();
  }
  private final Queue<Node> queue = new LinkedList<>();

}
